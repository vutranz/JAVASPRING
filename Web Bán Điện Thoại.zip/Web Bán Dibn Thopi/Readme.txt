Thông tin sinh viên:
1. Trần Vũ - 52000732 code phần back-end
2. Nguyễn Minh Nghĩa - 52000692 code phần font-end

Step-by-Step
Bước 1 Tải file về máy bỏ trong thư mục tự tạo (đặt tên tuỳ ý)
Bước 2 Mở springtoolsuite4 và chọn đường dẫn là file tạo ở bước 1 
Bươc 3 Tải database (tên web) mở Xampp lên và tạo tên databse tên web và import database vào
Bước 4 Nhấn vào tên file WEBMID chọn Run As -> Spring boot app
Bước 5 Vào trình duyện nhập http://localhost:8080/ để vào giao diện
Tài khoản admin
username: admin
password: 123 